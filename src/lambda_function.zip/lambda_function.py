import json
import base64
import gzip
import boto3
import os
from botocore.exceptions import ClientError

# Initialisation du client AWS EC2
ec2 = boto3.client('ec2')
# Récupération de l'ID de la NACL depuis les variables d'environnement
NACL_ID = os.environ.get('NACL_ID')

def get_next_rule_number(nacl_id):
    """Trouve le prochain numéro de règle disponible entre 1 et 99 pour le blocage."""
    response = ec2.describe_network_acls(NetworkAclIds=[nacl_id])
    entries = response['NetworkAcls'][0]['Entries']
    
    # On cherche les règles existantes pour le trafic entrant (Egress=False) en dessous de 100
    used_numbers = [e['RuleNumber'] for e in entries if not e['Egress'] and e['RuleNumber'] < 100]
    
    if not used_numbers:
        return 1  # Première règle de blocage
    
    next_rule = max(used_numbers) + 1
    if next_rule >= 100:
        print("AVERTISSEMENT : Plus de place dans la NACL (1-99).")
        return None
    return next_rule

def block_ip(ip_attacker):
    """Crée une règle NACL (Deny) pour bloquer une IP."""
    # Sécurité : Ne JAMAIS bloquer nos propres adresses IP internes (10.x.x.x)
    if ip_attacker.startswith("10.") or ip_attacker == "Inconnue":
        return

    try:
        rule_num = get_next_rule_number(NACL_ID)
        if not rule_num:
            return

        # Création de la règle de blocage
        ec2.create_network_acl_entry(
            NetworkAclId=NACL_ID,
            RuleNumber=rule_num,
            Protocol='-1', # -1 = Tous les protocoles
            RuleAction='deny',
            Egress=False,  # Faux = Trafic Entrant (Ingress)
            CidrBlock=f"{ip_attacker}/32" # /32 cible exactement cette machine
        )
        print(f"SOAR : L'IP {ip_attacker} a été bloquée (Règle #{rule_num}) !")
        
    except ClientError as e:
        if 'already exists' in str(e) or 'already been reached' in str(e):
            print(f"SOAR : Info : L'IP {ip_attacker} est peut-être déjà bloquée ou le numéro est pris.")
        else:
            print(f"Erreur API AWS : {e}")

def lambda_handler(event, context):
    cw_data = event['awslogs']['data']
    compressed_payload = base64.b64decode(cw_data)
    uncompressed_payload = gzip.decompress(compressed_payload)
    
    log_events = json.loads(uncompressed_payload)
    
    for log_event in log_events['logEvents']:
        raw_message = log_event['message']
        
        try:
            # On tente de décoder le message au format JSON (Suricata eve.json)
            suricata_alert = json.loads(raw_message)
            
            # Si c'est bien du JSON, on extrait les infos SecOps
            attaquant_ip = suricata_alert.get('src_ip', 'Inconnue')
            cible_ip = suricata_alert.get('dest_ip', 'Inconnue')
            
            # On vérifie si c'est bien une alerte (et pas un simple flux réseau)
            if suricata_alert.get('event_type') == 'alert':
                signature = suricata_alert.get('alert', {}).get('signature', 'Inconnue')
                print(f"Alerte suricata levée. Attaquant : {attaquant_ip} | Cible : {cible_ip} | Attaque : {signature}")
            else:
                print(f"Flux normal depuis : {attaquant_ip}")
                
        except json.JSONDecodeError:
            # Le message n'est pas du JSON (ex: le test manuel d'AWS)
            print(f"Test manuel ou Log non-JSON reçu : {raw_message}")

    return {
        'statusCode': 200,
        'body': json.dumps('Traitement terminé')
    }